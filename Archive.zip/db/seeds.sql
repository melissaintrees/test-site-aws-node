INSERT INTO tabletest (test_name) VALUES ('Beyond Meat Burger');
INSERT INTO tabletest (test_name) VALUES ('Impossible Burger');
INSERT INTO tabletest (test_name) VALUES ('Boca Burger');
INSERT INTO tabletest (test_name) VALUES ('Black Bean Burger');
INSERT INTO tabletest (test_name) VALUES ('Dr. Praegers');
INSERT INTO tabletest (test_name) VALUES ('Lentil Burger');


